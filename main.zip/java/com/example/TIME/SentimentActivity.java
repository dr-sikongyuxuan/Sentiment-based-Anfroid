package com.example.TIME;
import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.widget.Toast;

import java.io.*;
import java.util.HashMap;
import java.util.Map;
import java.io.BufferedReader;

public class SentimentActivity extends Activity{
    private static String TAG = "MenuActivity";
    public static String content;
    public static String modelFilePath = "model.txt";
    private static HashMap<String, Integer> parameters = null;  //用于存放模型
    private static Map<String, Double> catagory=null;
    private static String[] labels = {"好评", "差评", "总数","priorGood","priorBad"};
    InputStream inputStream = null;
    Reader reader = null;
    BufferedReader bufferedReader = null;
    @Override
    /*活动创建方法*/
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.layout_sentiment);//绑定布局文件

        Intent i = getIntent();
        content = i.getStringExtra("content");
        try {
            inputStream = getResources().openRawResource(R.raw.model);
            reader = new InputStreamReader(inputStream);// 字符流
            bufferedReader = new BufferedReader(reader); //缓冲流
            String temp;
            parameters = new HashMap<>();
            while ((temp = bufferedReader.readLine()) != null) {
                String[] split = temp.split("\t| ");
                String key = split[0];
                int value = Integer.parseInt(split[1]);
                parameters.put(key, value);
            }
            Log.d(TAG, "------------------Start---------------");
            calculateCatagory(); //分类
            String result = predict(content);
            Log.d(TAG,result);

            if (result.equals(labels[0]))
            {
                Toast.makeText(SentimentActivity.this,"用户情绪健康", Toast.LENGTH_SHORT).show();
            }
            else
            {
                Toast.makeText(SentimentActivity.this,"用户情绪消极", Toast.LENGTH_SHORT).show();
            }

        } catch (Exception e)
        {
            e.printStackTrace();
        }
    }

    public static void calculateCatagory() {
        catagory = new HashMap<>();
        double good = 0.0; //好评词频总数
        double bad = 0.0;   //差评的词频总数
        double total;   //总词频

        for (String key : parameters.keySet()) {
            Integer value = parameters.get(key);
            if (key.contains("好评-")) {
                good += value;
            } else if (key.contains("差评-")) {
                bad += value;
            }
        }
        total = good + bad;
        catagory.put(labels[0], good);
        catagory.put(labels[1], bad);
        catagory.put(labels[2], total);
        catagory.put(labels[3],good/total); //好评先验概率
        catagory.put(labels[4],bad/total);	//差评先验概率
    }
    private static String predict(String sentence) {
        String[] features = sentence.split("\t| ");
        // String prediction;

        //分别预测好评和差评
        double good = likelihoodSum(labels[0], features) + Math.log(catagory.get(labels[3]));
        double bad = likelihoodSum(labels[1], features) + Math.log(catagory.get(labels[4]));
        return good >= bad?labels[0]:labels[1];
    }

    //似然概率的计算
    public static double likelihoodSum(String label, String[] features) {
        double p = 0.0;
        Double total = catagory.get(label) + 1;//分母平滑处理
        for (String word : features) {
            Integer count = parameters.getOrDefault(label + "-" + word, 0) + 1;//分子平滑处理
            //计算在该类别的情况下是该词的概率，用该词的词频除以类别的总词频
            p += Math.log(count / total);
        }
        return p;
    }
}
