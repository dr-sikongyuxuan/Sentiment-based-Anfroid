package com.example.TIME;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;

/*用于显示开发信息的的活动，无特殊功能*/
public class AboutActivity extends Activity {
    @Override
    /*活动创建方法*/
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.layout_about);//绑定布局文件
    }
    public void change1(View v){ startActivity(new Intent(AboutActivity.this,About_2.class));finish();  }
}
