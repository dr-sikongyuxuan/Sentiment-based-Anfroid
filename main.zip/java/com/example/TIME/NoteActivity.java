package com.example.TIME;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import android.content.Intent;
import java.text.DateFormat;
import java.util.Calendar;
import java.util.Timer;

/*用于创建笔记的活动*/
public class NoteActivity extends Activity {
    EditText newNote;
    Button saveButton;
    dbhandler mydbhandler;
    Timer timer;

    /*活动创建方法*/
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.layout_note);//绑定布局文件
        mydbhandler=new dbhandler(this);//新建数据库管理类

        Calendar calendar = Calendar.getInstance();//获取当前日期
        String currentDate = DateFormat.getDateInstance(DateFormat.FULL).format(calendar.getTime());
        TextView textViewDate = findViewById(R.id.dateTV);//绑定日期控件
        textViewDate.setText(currentDate);//显示当前日期

        newNote=(EditText) findViewById(R.id.newNoteET);//绑定文本控件
        saveButton=(Button) findViewById(R.id.saveNoteBtn);//绑定保存控件

        /*监听“保存”控件*/
        saveButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String newEntry=newNote.getText().toString();//获取笔记（数据）名
                //将新建的笔记保存
                if(newNote.length()!=0){
                    Note n=new Note(newEntry);
                    addNote(n);
                    newNote.setText("");
                }else
                    { toastMessage("空事件无法添加"); }
                startActivity(new Intent(NoteActivity.this,MenuActivity.class));
            }
        });
    }
    /*将新建笔记添加到数据库*/
    public void addNote(Note newEntry){
        boolean insertNote=mydbhandler.addNote(newEntry);
        if(insertNote)
            { toastMessage("事件添加成功");}
        else
            { toastMessage("报错"); }
    }
    /*用于信息提示的函数，基于Toast*/
    private void toastMessage(String msg){
        Toast.makeText(this,msg,Toast.LENGTH_SHORT).show();
    }
}
