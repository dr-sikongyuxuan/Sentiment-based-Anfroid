package com.example.TIME;
/*笔记数据类*/
public class Note {
    String note;
    public Note(String Note) { this.note=Note; }//笔记数据
    public String getNote() { return this.note; }//读取笔记数据函数
}
