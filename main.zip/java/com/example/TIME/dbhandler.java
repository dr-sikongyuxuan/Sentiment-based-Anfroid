package com.example.TIME;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

/*笔记数据库管理类，基于SQLite数据库存储*/
public class dbhandler extends SQLiteOpenHelper {
    private static final int DATABASE_VERSION=1; //数据库版本
    private static final String DATABASE_NAME="notesManager";//库名
    private static final String TABLE_NAME="notes";//表名
    private static final String KEY_ID="id";//笔记（数据）编号
    private static final String KEY_NOTE="note";//笔记内容

    //构造方法
    public dbhandler(Context context)
        { super(context,DATABASE_NAME,null,DATABASE_VERSION); }
    //数据库创建
    @Override
    public void onCreate(SQLiteDatabase db) {
        //“创建数据库”的指令
        String CREATE_NOTES_TABLE="CREATE TABLE "+ TABLE_NAME +"("
                + KEY_ID +" INTEGER PRIMARY KEY," + KEY_NOTE +" TEXT" +")";
        db.execSQL(CREATE_NOTES_TABLE); //使用SQL命令
    }
    @Override
    //数据库升级
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        //“升级数据库”的指令
        db.execSQL("DROP TABLE IF EXISTS "+TABLE_NAME);
        onCreate(db);
    }
    //增加数据（笔记）
    public boolean addNote(Note note)
    {
        SQLiteDatabase db = this.getWritableDatabase();//以读写方式打开数据库
        ContentValues value = new ContentValues();//定义封装存储类
        value.put(KEY_NOTE, note.getNote());//读取笔记
        long result = db.insert(TABLE_NAME, null,value); //添加数据
        if(result==-1) return false; else return true;//判断是否成功添加
    }
    //获取数据
    public Cursor getNotes() {
        SQLiteDatabase db = this.getWritableDatabase(); //以读写方式打开数据库
        Cursor data=db.rawQuery("SELECT * FROM "+ TABLE_NAME, null);//查询
        return data;
    }
    //更新数据
    public void updateNote(Note note,int id)
    {
        SQLiteDatabase db = this.getWritableDatabase();//以读写方式打开数据库
        db.execSQL("UPDATE NOTES SET NOTE='"+note.getNote()+"' WHERE ID = "+id );//更新
        db.close();//关闭
    }
    //删除数据
    public void delete(int id)
    {
        SQLiteDatabase db = this.getWritableDatabase();//以读写方式打开数据库
        db.execSQL("DELETE FROM NOTES WHERE ID="+id);//删除符合ID的笔记
    }
}
