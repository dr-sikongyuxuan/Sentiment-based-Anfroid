package com.example.TIME;

import android.app.Activity;
import android.content.Intent;
import android.nfc.Tag;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import java.text.DateFormat;
import java.util.Calendar;
/*用于笔记编辑的活动*/
public class EditNoteActivity extends Activity {
    EditText newENNote;
    Button saveENButton,delENButton,SenButton;
    dbhandler mydbhandler;
    int getID;
    private static String TAG = "MenuActivity";
    public String text;
    @Override
    /*活动创建方法*/
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.layout_edit_note);//绑定布局

        Calendar calendar = Calendar.getInstance();//获取当前日期
        String currentDate = DateFormat.getDateInstance(DateFormat.FULL).format(calendar.getTime());
        TextView textViewDate = findViewById(R.id.dateENTV);//绑定日期控件
        textViewDate.setText(currentDate);//显示当前日期

        newENNote=(EditText) findViewById(R.id.EditNoteET);//绑定文本控件
        saveENButton=(Button) findViewById(R.id.saveNoteENBtn);//绑定保存控件
        delENButton=(Button) findViewById(R.id.deleteENBtn);//绑定删除控件
        SenButton = (Button) findViewById(R.id.SentimentBtn); //绑定分析控件
        mydbhandler=new dbhandler(this);//建立数据库管理类


        /*数据传递*/
        Intent intent = getIntent();
        Bundle bd = intent.getExtras();//获取传递的intent对象
        if(bd != null)
        {   //解包传递的intent对象
            String getName = (String) bd.get("note"); //笔记数据
            text = getName;
            getID=(int)bd.get("id");//笔记ID
            newENNote.setText(getName);//数据显示到文本控件
        }
        /*监听“保存”控件*/
        saveENButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String newEntry=newENNote.getText().toString();//获取笔记（数据）名
                mydbhandler.updateNote(new Note(newEntry),getID);//更新数据
                startActivity(new Intent(EditNoteActivity.this,MenuActivity.class));
            }
        });
        /*监听“删除”控件*/
        delENButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {   //响应
                mydbhandler.delete(getID);  //删除对应ID的笔记（数据）
                startActivity(new Intent(EditNoteActivity.this,MenuActivity.class));
            }
        });

        SenButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {   //响应
                Intent intent2 = new Intent(EditNoteActivity.this,SentimentActivity.class);
                intent2.putExtra("content", text); //key-"sff",通过key得到value-"value值"(String型)
                startActivity(intent2);
            }
        });
    }
}
