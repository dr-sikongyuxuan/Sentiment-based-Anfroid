package com.example.TIME;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;

/*用于显示开发信息的的活动，无特殊功能*/
public class About_2 extends Activity {
    @Override
    /*活动创建方法*/
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.layout_2about);//绑定布局文件
    }
    public void change2(View v){ startActivity(new Intent(About_2.this,AboutActivity.class)); finish(); }

}
