package com.example.TIME;
import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import java.util.Timer;
import java.util.TimerTask;

/*默认开始界面*/
public class WelcomeActivity extends Activity {
    Timer timer;
    @Override
    /*活动创建方法*/
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.layout_welcome);//绑定布局文件
        timer = new Timer();          //设置活动维持的时间
        timer.schedule(new TimerTask() {
            @Override
            public void run() {
                Intent intent=new Intent(WelcomeActivity.this,MenuActivity.class);
                startActivity(intent);finish(); }
        },3000);
    }
}
