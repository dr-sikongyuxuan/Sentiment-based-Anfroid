package com.example.TIME;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;

/*用于显示菜单界面的活动，引导启动其他活动*/
public class MenuActivity extends Activity {
    private static String TAG = "MenuActivity";
    /*活动创建方法*/
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.layout_menu);//绑定布局文件
    }
    /*，开启笔记列表活动*/
    public void note(View v){
        startActivity(new Intent(MenuActivity.this,ListActivity.class)); }
    /*开启活动*/
    public void about(View v){ startActivity(new Intent(MenuActivity.this,AboutActivity.class));  }
    /*响应“查看相册”控件，开启设置查看相册活动*/
    public void gallery(View v){ startActivity(new Intent(MenuActivity.this,GalleryActivity.class));}
}
