package com.example.TIME;

import android.app.Activity;
import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;
import java.util.ArrayList;
/*用于管理笔记列表的活动*/
public class ListActivity extends Activity {
    private static final String TAG="ListActivity";
    dbhandler mydbHandler;
    private ListView myListView;

    /*活动创建方法*/
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.layout_list);//绑定布局文件
        myListView=(ListView)findViewById(R.id.listViewID);//绑定列表控件
        mydbHandler=new dbhandler(this);//新建数据库管理类
        populateListView();
    }
    private void populateListView(){
        final Cursor data = mydbHandler.getNotes(); //获取数据，保存到Cursor类
        //遍历Cursor类，将数据转存到数组中
        final ArrayList<String> notelist = new ArrayList<>();
        while (data.moveToNext())
            { notelist.add(data.getString(1)); }
        //为笔记列表控件绑定适配器
        myListView.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_list_item_1,notelist));
        /*监听笔记列表控件*/
        myListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            /*响应点击*/
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                Note name = new Note(adapterView.getItemAtPosition(i).toString());//获取点击的列表项
                Cursor data=mydbHandler.getNotes();//获取数据库，保存到Cursor类
                int itemID=-1;
                while (data.moveToNext()){        //寻找匹配的笔记数据
                    if(name.getNote().equals(data.getString(1)))
                    { itemID = data.getInt(0); break; }
                }
                if(itemID>-1){//找到匹配数据，打开对应笔记
                    Intent i1 = new Intent(view.getContext(),EditNoteActivity.class);
                    i1.putExtra("note", name.getNote());i1.putExtra("id", itemID);
                    startActivity(i1);
                }else//提示无匹配数据
                    { toastMessage("无匹配的事件");}
            }
        });
    }
    private void toastMessage(String msg)
        { Toast.makeText(this,msg,Toast.LENGTH_SHORT).show(); }
        /*响应“新建”控件*/
    public void NewNote(View v){
        startActivity(new Intent(ListActivity.this,NoteActivity.class));
    }
}
