package com.example.TIME;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.provider.MediaStore;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import java.io.IOException;
/*用于显示相册图片的活动*/
public class GalleryActivity extends Activity {
    Button selectImage;
    ImageView imageView;
    private int REQUEST_CODE = 1;

    @Override
    /*活动创建方法*/
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.layout_gallery);//绑定布局

        selectImage = (Button) findViewById(R.id.selectImage);//绑定“选择图片”控件
        imageView = (ImageView) findViewById(R.id.imageView);//绑定显示图片的控件
        /*监听“选择图片”控件*/
        selectImage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent();
                intent.setType("image/*");//指定图像数据类型
                intent.setAction(Intent.ACTION_GET_CONTENT);//调用系统应用（此处即为图库）
                //调用图库选择图片并返回
                startActivityForResult(Intent.createChooser(intent, "Select Picture"),REQUEST_CODE);
            }
        });
    }
    /*重写onActivityResult，接收startActivityForResult返回的图片数据*/
    @Override
    protected  void onActivityResult(int requestCode,int resultCode,Intent data){
        super.onActivityResult(requestCode,resultCode,data);
        //核对请求码
        if(requestCode == REQUEST_CODE && resultCode == RESULT_OK && data != null&&data.getData() != null){
            Uri uri = data.getData();//获取返回的图像数据
            try{
                imageView.setImageBitmap(MediaStore.Images.Media.getBitmap(getContentResolver(),uri));//显示图像
            }catch (IOException e){//报错信息
                e.printStackTrace();
            }
        }
    }
}
